#!/bin/sh
source /etc/profile
database=$1
username=$2
password=$3
tablename=$4
filename=$5
seprator=$6
control=$7
##���ݿ�����ִ�к���
function exec_sql()
{
#sqlplus -s $username/$password@$database <$1;
#commit;
#exit
#eof
su - oracle <<EOF
        sqlplus -S $username/$password@$database 
        $1;
	commit;
        exit;
EOF
}
##������Ŀ�����д��NUM�ļ�
touch num
echo $control>num
start_time=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`
##��ȡNUM�ļ������ݲ��淶�����c1 c2 c3 c4
awk -F'[,]' '{printf $1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9" "$10" "$11" "$12" "$13" "$14" "$15" "$16"\n"}' num|while read c1 c2 c3 c4 c5 c6 c7 c8 c9 c10 c11 c12 c13 c14 c15 c16
do
        		
####ͨ����ȡ��c1 c2 c3 c4 �淶��ȡ�ļ������͸�SQL���
awk -F$seprator '{printf $2 " " $3 " " $4 " " $5 " " $6 " " $7 " " $8 " " $9 " " $10 " " $11 " " $12 " " $13 " " $14 " " $15 " " $16 " " $17"\n"}' $filename | while read code1 code2 code3 code4 code5 code6 code7 code8 code9 code10 code11 code12 code13 code14 code15 code16 code17 code18
do
EXEC_SQL="insert into $tablename (insert_time,${c1},${c2},${c3},${c4},${c5},${c6},${c7},${c8},${c9},${c10},${c11},${c12},${c13},${c14},${c15},${c16}) values(sysdate,'${code1}',to_date('${code2} ${code3}', 'yyyy-mm-dd hh24:mi:ss'),'${code4}','${code5}','${code6}','${code7}',to_date('${code8} ${code9}', 'yyyy-mm-dd hh24:mi:ss'),'${code10}','${code11}','${code12}','${code13}','${code14}','${code15}','${code16}','${code17}','${code18}')"
exec_sql "${EXEC_SQL}"
echo "${EXEC_SQL}"
done
done
finish_time=`date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"`
duration=$(($(($(date +%s -d "$finish_time")-$(date +%s -d "$start_time")))))
echo "this shell script execution duration: $duration"
rm -rf num
